function init(c) {
  chrome.windows.getCurrent(function (currentWindow) {
    chrome.tabs.query({ active: true, windowId: currentWindow.id }, function (
      activeTabs
    ) {
      activeTabs.map(function (tab) {
        chrome.tabs.executeScript(tab.id, { code: c });
      });
    });
  });
}
document.addEventListener(
  "DOMContentLoaded",
  function () {
    document.querySelector("#site").addEventListener("click", function () {
      init("window.open('https://hoodjs.github.io/rp-clue/')");
    });
    document.querySelector("#repo").addEventListener("click", function () {
      init("window.open('https://github.com/hoodJS/rp-clue')");
    });
    document.querySelector("#disc").addEventListener("click", function () {
      init("window.open('https://discord.gg/YaguZx4')");
    });
  },
  false
);
