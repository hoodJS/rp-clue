if (!window.rpc_iii_inject)
  document.body.appendChild(document.createElement`script`).src =
    "https://hoodjs.github.io/rp-clue/index.user.js?t=" + Date.now();
else alert("Script was already injected");
window.rpc_iii_inject = true;
